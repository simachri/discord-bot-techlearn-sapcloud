"""
discord-py-slash-command.utils
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Utility functions for slash command.

:copyright: (c) 2020-2021 eunwoo1104
:license: MIT
"""

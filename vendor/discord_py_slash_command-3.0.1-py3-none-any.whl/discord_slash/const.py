"""Discord Slash Constants"""

__version__ = "3.0.1"

BASE_API = "https://discord.com/api/v8"

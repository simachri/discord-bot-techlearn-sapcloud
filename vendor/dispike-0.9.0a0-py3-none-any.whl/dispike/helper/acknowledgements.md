# These helpers were adapted from the discord.py library.
